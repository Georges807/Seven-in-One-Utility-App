﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Object_Oriented_Project_S2
{
    public partial class frm649 : Form
    {
        public frm649()
        {
            InitializeComponent();
            string dir = @"C:\Test\";
            //you can use relative path .\ => where the .exe is
            //or ..\ => one folder up where the .exe is.
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);
        }

        private void frm649_Load(object sender, EventArgs e)
        {

        }
    }
}
